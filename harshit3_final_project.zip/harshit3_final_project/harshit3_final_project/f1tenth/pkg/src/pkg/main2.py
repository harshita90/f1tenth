# "I certify that the code and data in this assignment were generated independently, using only the tools
# and resources defined in the course and that I did not receive any external help, coaching or contributions
# during the production of this work."

import gym
import torch
from gym import spaces
import matplotlib.pyplot as plt
import numpy as np
import time
import random
import sys
import os
import torch.optim as optim
from pkg.ppo import Actor

current_dir = os.path.abspath(os.path.dirname(__file__))
print(current_dir)
sys.path.append(current_dir)

RACETRACK = 'SOCHI'
env = gym.make('f110_gym:f110-v0',
                       map="{}/maps/{}".format(current_dir, RACETRACK),
                       map_ext=".png", num_agents=1)

state_space = 1080
action_space = 2
actor = Actor(state_space,action_space)
poses = np.array([[-21.839666763757506,-8.915693807442764,0.9327401040628089]])
#poses = np.array([[0.8007017, -0.2753365, 4.1421595]])
#poses = np.array([[-28.30250095416897,-34.621099995448056,3.4208437794287834]])
actor = torch.load('/home/harshita/f1tenth/pkg/src/pkg/actor7.pt')
actor.eval()

if __name__ == '__main__':
    s = 0
    r = 0
    re = []
    st = []
    done = False
    obs, reward, done, info = env.reset(poses=poses)
    env.render()
    while not done:
        s = s + 1
        r = r + reward
        obsv = torch.tensor(obs['scans'],dtype=torch.float)
        obsv = torch.reshape(obsv,(-1,))
        actor_values = actor.forward(obsv)
        a = actor_values
        a = torch.reshape(actor_values,(1,2))
        a = a.detach().numpy()
        obs, reward, done, info = env.step(a)
        re.append(r)
        st.append(s)
        env.render('human')
    fig1, (ax1, ax2) = plt.subplots(1,2)
    fig1.suptitle("Rewards and steps per episode for 1000 episodes")
    ax1.plot(re)
    ax2.plot(st)
    plt.show()