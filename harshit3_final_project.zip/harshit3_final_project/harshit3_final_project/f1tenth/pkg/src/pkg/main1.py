# "I certify that the code and data in this assignment were generated independently, using only the tools
# and resources defined in the course and that I did not receive any external help, coaching or contributions
# during the production of this work."

import gym
import torch
from gym import spaces
import matplotlib.pyplot as plt
import numpy as np
import time
import random
import sys
import os
import torch.optim as optim
from pkg.ppo import Actor, Critic, Q_Value

current_dir = os.path.abspath(os.path.dirname(__file__))
print(current_dir)
sys.path.append(current_dir)

RACETRACK = 'SOCHI'
env = gym.make('f110_gym:f110-v0',
                       map="{}/maps/{}".format(current_dir, RACETRACK),
                       map_ext=".png", num_agents=1)

def _pack_odom(obs, i):
    keys = {
        'poses_x': 'pose_x',
        'poses_y': 'pose_y',
        'poses_theta': 'pose_theta',
        'linear_vels_x': 'linear_vel_x',
        'linear_vels_y': 'linear_vel_y',
        'ang_vels_z': 'angular_vel_z',
    }
    return {single: obs[multi][i] for multi, single in keys.items()}

alpha = 0.1
state_space = 1080
action_space = 2
actor = Actor(state_space,action_space)
critic = Critic(state_space)
q = Q_Value(state_space,action_space)
c = 0
returns = []
values = []
r = []
st = []
re = []
actions_old = torch.tensor([0,0],dtype=torch.float)
actor_optimizer = optim.Adam(actor.parameters(),lr=0.9)
critic_optimizer = optim.Adam(critic.parameters(),lr=0.9)
q_optimizer = optim.Adam(q.parameters(),lr=0.9)
#poses = np.array([[-21.839666763757506,-8.915693807442764,0.9327401040628089]])
#poses = np.array([[0.8007017, -0.2753365, 4.1421595]])
poses = np.array([[-28.30250095416897,-34.621099995448056,3.4208437794287834]])
actor = torch.load('/home/harshita/f1tenth/pkg/src/pkg/actor6.pt')
critic = torch.load('/home/harshita/f1tenth/pkg/src/pkg/critic6.pt')
q = torch.load('/home/harshita/f1tenth/pkg/src/pkg/q6.pt')
actor.eval()
critic.eval()
q.eval()

class Agent:
    def __init__(self,env):
        self.env = env
        self.observation_space = env.observation_space
        self.action_space = env.action_space
    
    def compute_gauss(self,actor_values):
        a = actor_values.detach().numpy()
        m = np.mean(a)
        u = np.std(a)
        return m,u
    
    def step(self,m,u):
        actions = np.random.normal(m,u,2)
        return actions
    
    def ratios(self,actions_old,actions):
        r = torch.sum(actions_old)/torch.sum(actions)
        return r
    
    def learn(self,adv,r):
       #r_clip = torch.clip(r,0.2,1.8)
        r = r*adv
       #r_clip = r_clip*adv
        loss = torch.sum(r)
        return loss

if __name__ == '__main__':
    agent = Agent(env)
    obs, reward, done, info = env.reset(poses=poses)
    env.render()
    s = 0
    c = 0
    rew = 0
    i = 1
    while i>0:
        c = c + 1
        s = s + 1
        obsv = torch.tensor(obs['scans'],dtype=torch.float)
        obsv = torch.reshape(obsv,(-1,))
        #obsv = torch.clamp(obsv,0,10)
        actor_values = actor.forward(obsv)
        critic_values = critic.forward(obsv)
        a = actor_values
#         a[0] = 20*a[0]
#         a[1] = 0.34*a[1]
        a = torch.reshape(actor_values,(1,2))
        a = a.detach().numpy()
        print(a)
#         m, u = agent.compute_gauss(actor_values)
#         actions = agent.step(m,u)
#         a.append(actor_values)
#         a = np.array(a,dtype=float)
        obs, reward, done, info = env.step(a)
#         actions = torch.from_numpy(actions)
#         actions = actions.float()
        rew = rew + reward
        reward = [reward]
        reward = torch.tensor(reward,dtype=torch.float)
        inpt = torch.cat([reward,obsv,actor_values])
        qv = q.forward(inpt)
        returns.append(critic_values.item())
        values.append(qv.item())
        r.append(agent.ratios(actions_old,actor_values))
        actions_old = actor_values
        if obs['lap_counts'].item() == 1:
            torch.save(actor,'/home/harshita/f1tenth/pkg/src/pkg/actor7.pt')
            torch.save(critic,'/home/harshita/f1tenth/pkg/src/pkg/critic7.pt')
            torch.save(q,'/home/harshita/f1tenth/pkg/src/pkg/q7.pt')
            break
        if obs['collisions'].item()>0:
            print(obs['poses_x'],obs['poses_y'],obs['poses_theta'])
            obs, reward, done, info = env.reset(poses=poses)
            torch.save(actor,'/home/harshita/f1tenth/pkg/src/pkg/actor7.pt')
            torch.save(critic,'/home/harshita/f1tenth/pkg/src/pkg/critic7.pt')
            torch.save(q,'/home/harshita/f1tenth/pkg/src/pkg/q7.pt')
            
            break
        if c%10 == 0:
            returns = torch.tensor(returns,requires_grad=True)
            values = torch.tensor(values,requires_grad=True)
            r = torch.tensor(r)
            adv = returns - values
            actor_loss = agent.learn(adv,r)
            returns = []
            values = []
            r = []
            critic_loss = torch.sum(adv)*alpha
#             q_loss = critic_loss
            actor.update_weights(actor_loss,actor_optimizer)
            critic.update_weights(critic_loss,critic_optimizer)
#             q.update(q_loss,q_optimizer)
        st.append(s)
        re.append(rew)
#             s = 0
#             rew = 0
        env.render('human')
    print("Number of steps taken:",c)
    fig1, (ax1, ax2) = plt.subplots(1,2)
    fig1.suptitle("Rewards and steps per episode for 1000 episodes")
    ax1.plot(re)
    ax2.plot(st)
    plt.show()